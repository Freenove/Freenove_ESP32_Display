
# Renderers and GPUs


```eval_rst

.. toctree::
   :maxdepth: 2

   sw
   sdl
   arm-2d
   pxp-vglite
   dma2d
```

