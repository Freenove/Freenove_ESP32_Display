This is libogg from Xiph, modified to build under Arduino by <earlephilhower@yahoo.com>.

OGG license/etc. unchanged.
